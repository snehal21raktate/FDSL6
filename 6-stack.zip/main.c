#include <stdio.h>
#include <stdlib.h>
#define MAX 100  

struct Stack {
    int items[MAX];
    int top;
};


void init(struct Stack* s) {
    s->top = -1;
}


int isFull(struct Stack* s) {
    return s->top == MAX - 1;
}

int isEmpty(struct Stack* s) {
    return s->top == -1;
}


void push(struct Stack* s, int item) {
    if (isFull(s)) {
        printf("Stack Overflow! Cannot push %d\n", item);
    } else {
        s->items[++(s->top)] = item;
        printf("Pushed %d onto stack\n", item);
    }
}

int pop(struct Stack* s) {
    if (isEmpty(s)) {
        printf("Stack Underflow! Cannot pop\n");
        return -1;
    } else {
        return s->items[(s->top)--];
    }
}


int peek(struct Stack* s) {
    if (isEmpty(s)) {
        printf("Stack is empty\n");
        return -1;
    } else {
        return s->items[s->top];
    }
}


void display(struct Stack* s) {
    if (isEmpty(s)) {
        printf("Stack is empty\n");
    } else {
        printf("Stack elements (top to bottom):\n");
        for (int i = s->top; i >= 0; i--) {
            printf("%d\n", s->items[i]);
        }
    }
}


int main() {
    struct Stack s;
    init(&s);

    push(&s, 10);
    push(&s, 20);
    push(&s, 30);
    display(&s);

    printf("Top element is %d\n", peek(&s));

    int popped = pop(&s);
    if (popped != -1) {
        printf("Popped %d from stack\n", popped);
    }

    display(&s);

    return 0;
}
